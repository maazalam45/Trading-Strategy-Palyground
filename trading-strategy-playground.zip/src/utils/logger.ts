export const log = (...a: any[]) => console.log('[TV]', ...a)
export const warn = (...a: any[]) => console.warn('[TV]', ...a)
export const err = (...a: any[]) => console.error('[TV]', ...a)
