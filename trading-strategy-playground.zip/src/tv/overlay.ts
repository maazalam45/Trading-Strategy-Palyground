import type {
  TTradeSignals,
  Fractal,
  OrderBlock,
  Sweep,
} from "../model/ttrades";

type Chart = any; // TV chart instance
type Shape = any;
const ent = new Map<string, Shape>(); // keep handles to update/cleanup

const sec = (ms: number) => Math.floor(ms / 1000);

export function clearOverlay() {
  for (const [, s] of ent) {
    try {
      s.remove?.();
    } catch {}
  }
  ent.clear();
}

function key(...parts: (string | number)[]) {
  return parts.join("|");
}

export function renderFractals(chart: Chart, fractals: Fractal[]) {
  for (const f of fractals) {
    const k = key("fr", f.time, f.kind, f.depth);
    if (ent.has(k)) continue;
    const shape = chart.createMultipointShape(
      [{ time: sec(f.time), price: f.price }],
      {
        shape: "arrow_down", // arrow_down for highs, arrow_up for lows
        text: f.kind === "high" ? `C${f.depth}` : `C${f.depth}`,
        lock: false,
        disableSelection: true,
        overrides: {
          color: f.kind === "high" ? "#ef4444" : "#10b981",
          fontsize: 12,
        },
      }
    );
    ent.set(k, shape);
  }
}

export function renderSweeps(chart: Chart, sweeps: Sweep[]) {
  for (const s of sweeps) {
    const k = key("sw", s.timeA, s.timeB, s.kind);
    if (ent.has(k)) continue;
    const shape = chart.createMultipointShape(
      [
        { time: sec(s.timeA), price: s.level },
        { time: sec(s.timeB), price: s.level },
      ],
      {
        shape: "trend_line",
        lock: false,
        disableSelection: true,
        overrides: {
          color: s.kind === "equalHighs" ? "#93c5fd" : "#fbcfe8",
          linewidth: 1,
          linestyle: 1, // dotted
        },
      }
    );
    ent.set(k, shape);
  }
}

export function renderOrderBlocks(chart: Chart, obs: OrderBlock[]) {
  for (const ob of obs) {
    const k = key("ob", ob.timeStart, ob.timeEnd, ob.dir);
    if (ent.has(k)) continue;
    const shape = chart.createMultipointShape(
      [
        { time: sec(ob.timeStart), price: ob.high },
        { time: sec(ob.timeStart), price: ob.low },
        { time: sec(ob.timeEnd), price: ob.low },
        { time: sec(ob.timeEnd), price: ob.high },
      ],
      {
        shape: "rectangle",
        lock: false,
        disableSelection: true,
        filled: true,
        overrides: {
          color: ob.dir === "bull" ? "#22c55e" : "#ef4444",
          backgroundColor:
            ob.dir === "bull" ? "rgba(34,197,94,.10)" : "rgba(239,68,68,.10)",
          linewidth: 1,
        },
      }
    );
    ent.set(k, shape);
  }
}

export function renderEquilibrium(
  chart: Chart,
  eq?: { time: number; level: number }
) {
  if (!eq) return;
  const k = key("eq", eq.time);
  if (ent.has(k)) return;
  const shape = chart.createMultipointShape(
    [
      { time: sec(eq.time - 60_000), price: eq.level },
      { time: sec(eq.time + 60_000), price: eq.level },
    ],
    {
      shape: "trend_line",
      lock: false,
      disableSelection: true,
      overrides: { color: "#eab308", linewidth: 2 },
    }
  );
  ent.set(k, shape);
}

export function renderTTrade(chart: Chart, sig: TTradeSignals) {
  renderFractals(chart, sig.fractals);
  renderSweeps(chart, sig.sweeps);
  renderOrderBlocks(chart, sig.orderBlocks);
  renderEquilibrium(chart, sig.equilibrium);
}
