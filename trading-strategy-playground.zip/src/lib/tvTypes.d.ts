export {}
declare global { interface Window { TradingView: any } }
